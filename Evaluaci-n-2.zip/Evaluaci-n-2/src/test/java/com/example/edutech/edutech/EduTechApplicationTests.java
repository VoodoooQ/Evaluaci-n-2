package com.example.edutech.edutech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduTechApplicationTests {

	@Test
	void contextLoads() {
	}

}
